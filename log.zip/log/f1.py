import logging
logging.info("F1 started")