print "this is file1"
a=10
b=20
c=30
def fun():
	print "this is fun in file1"
fun()